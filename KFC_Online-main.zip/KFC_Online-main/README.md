# KFC_Online
-Creating a web application similar to KFC using HTML, CSS, and JavaScript involves designing a user-friendly interface for ordering food online
- [Live Demo](https://tipu30.github.io/KFC_Online/)
